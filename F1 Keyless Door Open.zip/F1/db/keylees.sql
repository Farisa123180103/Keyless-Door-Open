-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Jan 2021 pada 13.53
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `keylees`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`id`, `username`, `password`, `email`) VALUES
(0, 'admin', '$2y$10$7ItA3TktfYzYJkMqBSZI3e10VoVlXOsjgcQoPnsHi7Mt0d.1mOHJm', 'admin@gmail.com'),
(1, 'adityo', '$2y$10$BFhYCY.NryXVRMI49T1YyuF4JXYzbEVf3f64bE3MrvcuFVMa02EFW', 'adityopratama9@gmail.com'),
(2, 'elsa', '$2y$10$G8JU8N5TIzdDCycVgd3Kiuwo990oRduGePTHbWQTVVgKuUdJGSLg.', '123180024@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `no` int(11) NOT NULL,
  `uid` varchar(60) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `status` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `date` text NOT NULL,
  `keterangan` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`no`, `uid`, `nama`, `status`, `date`, `keterangan`) VALUES
(1, '046E1CAA705B80', 'Risa', '', 'Tuesday,19-01-2021 07:32:01 pm', 'On time'),
(2, '046E1CAA705B80', 'Risa', 'Pulang', 'Tuesday,19-01-2021 07:32:12 pm', 'On time'),
(3, '046E1CAA705B80', 'Risa', 'Pergi', 'Tuesday,19-01-2021 07:32:22 pm', 'On time'),
(4, '046E1CAA705B80', 'Risa', 'Pulang', 'Tuesday,19-01-2021 07:47:52 pm', 'On time');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
