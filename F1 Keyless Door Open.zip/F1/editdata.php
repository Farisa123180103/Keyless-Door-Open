<html>
    
    <head> EDIT DATA </head>

<body>
    <?php
        include 'koneksi.php';
        $id_user=$_GET['id'];
        $query= mysqli_query($conn, "SELECT * from user where id_user='$id_user'"); //query untuk mengambil data
        $data=mysqli_fetch_array($query);
    ?>

<form method="POST" action="updatedata.php" >
    <input type="hidden" name="id_user"
    value="<?php echo $data['id_user']; ?>"> 
    <br>
    <table width="100%" border="0">
            <tr> 
                <td> ID User </td>
                <td><input type="text" name="id_user"
                    value="<?php echo $data['id_user']; ?>"> </td>
            </tr>
            <tr> 
                <td> Nama </td>
                <td><input type="text" name="nama"
                    value="<?php echo $data['nama']; ?>"> </td>
            </tr>
            <tr> 
                <td> Status </td>
                <td><input type="text" name="status"
                    value="<?php echo $data['status']; ?>"></td>
            </tr>
            <tr> 
                <td> Date </td>
                <td><input type="text" name="date"
                    value="<?php echo $data['date']; ?>"></td>
            </tr>


            <tr>
                <td> </td>
                <td><input type ="submit" value="submit"></td>
            </tr>
            
        </table> 
    
</form> 
</body>
</html>
