<?php
        include "koneksi.php";
        $query=mysqli_query($conn, "SELECT * from user")
?>

<!DOCTYPE html>
<html>

<head>
  <title>Pengunjung</title>
</head>

<body>
    <h3> TAMBAH USER </h3>
    <form action="prosesdata.php" method="post">
        <table width="100%" border="0">
            
            <tr> 
                <td> Id User </td>
                <td><input type="text" name="id_user"></td>
            </tr>
            <tr> 
                <td> Nama </td>
                <td><input type="text" name="nama"></td>
            </tr>
            <tr> 
                <td> Status </td>
                <td>
                    <input type="checkbox" name="status[]" id="status[]" value="pulang">Pulang<br>
                    <input type="checkbox" name="status[]" id="status[]" value="pergi">Pergi<br>
                </td>
            </tr>
            <tr> 
                <td> Date </td>
                <td><input type="hidden" name="date" value="<?php date_default_timezone_set('Asia/Jakarta'); echo date('l,d-m-Y h:i:s a'); ?>"></td>
            </tr>
            <tr> 

            <tr>
                <td> </td>
                <td><input type ="submit" value="submit"></td>
            </tr>
            
        </table> 
    </form>
    
</body>
</html> 