<?php
    include "koneksi.php";
    $id_user = $_GET['id'];
    $query=mysqli_query($conn, "delete from user where id_user='$id_user'"); //query untuk hapus data
    
    if($query)
    {
        echo "Proses Hapus Berhasil, Ingin lihat hasil
        <a href='tampildata.php'> disini </a>";
    }
    else
    {
        echo "proses input gagal";
    }


?>