<?php

require_once '../F1/login/Auth.php';

if(!$auth->isLoggedIn()) {
 header('location:index.php');
}
?>
<?php include 'koneksi.php'; ?>


<html>
    <head>
        
        <title> Tampil Data </title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
    
    <body>
        <center>
        <h1>Data Pengunjung</h1>
        </center>
        <center>
<form action="tampildata.php" method="get">
    <label>Cari :</label>
    <input type="text" name="cari">
    <input type="submit" value="Cari">
</form>

<?php 
    if(isset($_GET['cari'])){
        $cari = $_GET['cari'];
        echo "<b>Hasil pencarian : ".$cari."</b>";
    }
    $date = date_default_timezone_set('Asia/Jakarta'); 
    $tgl = date('l,d-m-Y');
    $periksa=mysqli_query($conn,"select * from user where date like '$tgl%'");
        while($q=mysqli_fetch_array($periksa)){	
            if($q['keterangan']=="Late" && $q['status']=="Pulang"){	
                ?>	
                <script>
                    $(document).ready(function(){
                        $('#pesan_sedia').css("color","red");
                        $('#pesan_sedia').append("<span class='glyphicon glyphicon-asterisk'></span>");
                    });
                </script>
                <?php
                echo "<div style='padding:5px' class='alert alert-warning' align='center'><span class='fas fa-exclamation-circle '></span><a style='color:red'>". $q['nama']."</a> Pulang Terlambat !!</div>";	
            }
            if($q['keterangan']=="Late" && $q['status']=="Pergi"){	
                ?>	
                <script>
                    $(document).ready(function(){
                        $('#pesan_sedia').css("color","red");
                        $('#pesan_sedia').append("<span class='glyphicon glyphicon-asterisk'></span>");
                    });
                </script>
                <?php
                echo "<div style='padding:5px' class='alert alert-warning' align='center'><span class='fas fa-exclamation-circle '></span> <a style='color:red'>". $q['nama']."</a> Pergi Terlalu Larut !!</div>";	
            }
        } 

?>

<table class="table table-hover">
  <thead>
    <tr>

        <th scope="col">No</th>
        <th scope="col">ID User</th>
        <th scope="col">Nama</th>
        <th scope="col">Status</th>
        <th scope="col">Date</th>
        <th scope="col">Keterangan</th>

    </tr>
  </thead>
  <tbody>
     <?php
            include 'koneksi.php';
           
            if(isset($_GET['cari'])){
            $cari = $_GET['cari'];
            $data = mysqli_query($conn, "select * from user where no like '%".$cari."%' or uid like '%".$cari."%'
                or nama like '%".$cari."%' or status like '%".$cari."%'or date like '%".$cari."%'or keterangan like '%".$cari."%'"); 
            }
            else
            {
            $data = mysqli_query($conn, "select *from user");
            }
            $i = 1;
            while($d = mysqli_fetch_array($data)){
            ?>
            <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo $d['uid']; ?></td>
                <td><?php echo $d['nama']; ?></td>
                <td><?php echo $d['status']; ?></td>
                <td><?php echo $d['date']; ?></td>
                <td><?php echo $d['keterangan']; ?></td>
            </tr>
            <?php 
                } 
            ?>
    
  </tbody>
</table>
        
        </center>
        
        <br>
        <center> <a href="index.php" class="btn btn-primary"> Home </a></center>
    
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script> 
    </body>

</html>