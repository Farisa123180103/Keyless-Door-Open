<?php
    $hostname = "localhost"; //app yang digunakan untuk db
    $username = "root"; //username 
    $password = ""; //password   
    $database = "keylees"; //database yang digunakan                   


    $conn= new mysqli($hostname, $username, $password, $database);
   
    if($conn->connect_error)
    {
        exit();
        die('maaf koneksi gagal :'. $connect->error);
    }
?>