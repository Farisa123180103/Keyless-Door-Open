<?php
    include 'koneksi.php';

    $id_user = $_POST['id_user'];
    $nama = $_POST['nama'];
    $status = $_POST['status'];
    $date = $_POST['date'];
    
        
$query = mysqli_query($conn, "UPDATE user SET id_user='$id_user', nama='$nama', status='$status', date='$date'" ) //query untuk tambah data
    or die(mysqli_error($conn));

if ($query)
{
echo "proses berhasil, ingin lihat hasil
    <a href='tampildata.php' > Disini </a>";
}
else
{
    echo "Ups...gagal";
}
?>


