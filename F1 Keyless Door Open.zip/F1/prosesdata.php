<?php
include "koneksi.php";

$uid = $_GET['uid'];
if ($uid =="046E1CAA705B80"){
    $nama="Risa";

}
else if ($uid =="DA038A19"){
    $nama="KTP2";

}

$data = mysqli_query($conn, "SELECT * FROM user WHERE uid='$uid' ORDER BY no DESC LIMIT 1") or die(mysqli_error($conn));
while ($d = mysqli_fetch_array($data)){
    if($d['status']=="Pulang"){
        $status = "Pergi";
    } else {
        $status = "Pulang";
    }
}
$date = date_default_timezone_set('Asia/Jakarta'); 
$tgl = date('l,d-m-Y h:i:s a');
$jam = date("H:i:s");

$keterangan = (strtotime("09:52:00") - strtotime($jam)<0) ? "Late" : "On time";
$query= mysqli_query($conn, "insert into user
                    values('','$uid', '$nama', '$status', '$tgl', '$keterangan')") //query untuk insert data
        or die(mysqli_error($conn));

if ($query)
{
    ?>
        <script type="text/javascript">
            alert("Ada Yang Masuk!!!");
            window.location.href="tampildata.php";
        </script> <?php
    // echo "proses berhasil, ingin lihat hasil
    //     <a href='tampildata.php'> Disini </a>";
}
else
{
    echo "Ups...gagal";
}



?>